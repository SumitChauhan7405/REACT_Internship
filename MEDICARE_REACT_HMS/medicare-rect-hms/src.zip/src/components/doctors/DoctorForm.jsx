import { useEffect, useState } from "react";
import { addDoctor, updateDoctor } from "../../services/doctorService";
import "../../assets/css/components/patient-form.css";

const DoctorForm = ({ onSuccess, editDoctor, clearEdit }) => {
    const [form, setForm] = useState({
        name: "",
        department: "",
        availableDays: [],
        timeSlots: [],
        consultationFee: "",
        image: ""
    });

    useEffect(() => {
        if (editDoctor) setForm(editDoctor);
    }, [editDoctor]);

    const handleChange = (e) => {
        const { name, value, files } = e.target;

        if (name === "availableDays") {
            const values = [...e.target.selectedOptions].map(o => o.value);
            setForm({ ...form, availableDays: values });
        } else if (name === "image" && files[0]) {
            // store ONLY filename
            setForm({ ...form, image: files[0].name });
        } else {
            setForm({ ...form, [name]: value });
        }
    };

    const toggleSlot = (slot) => {
        setForm({
            ...form,
            timeSlots: form.timeSlots.includes(slot)
                ? form.timeSlots.filter(t => t !== slot)
                : [...form.timeSlots, slot]
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const payload = {
            ...form,
            consultationFee: Number(form.consultationFee)
        };

        if (editDoctor) {
            await updateDoctor(editDoctor.id, payload);
            clearEdit();
        } else {
            await addDoctor({
                id: `DOC-${Date.now()}`,
                ...payload
            });
        }

        onSuccess();
        setForm({
            name: "",
            department: "",
            availableDays: [],
            timeSlots: [],
            consultationFee: "",
            image: ""
        });
    };

    return (
        <div className="patient-form-card">
            <div className="form-header">
                <h5>{editDoctor ? "Edit Doctor" : "Add Doctor"}</h5>
                <p>Doctor details & OPD availability</p>
            </div>

            <form onSubmit={handleSubmit}>
                <div className="form-grid">

                    <div>
                        <label>Doctor Name</label>
                        <input name="name" required value={form.name} onChange={handleChange} />
                    </div>

                    <div>
                        <label>Department</label>
                        <select name="department" required value={form.department} onChange={handleChange}>
                            <option value="">Select</option>
                            <option>Cardiology</option>
                            <option>Orthopedics</option>
                            <option>Neurology</option>
                            <option>Dermatology</option>
                            <option>ENT</option>
                            <option>General Medicine</option>
                        </select>
                    </div>

                    <div>
                        <label>Available Days</label>
                        <select name="availableDays" multiple value={form.availableDays} onChange={handleChange}>
                            <option>Mon</option>
                            <option>Tue</option>
                            <option>Wed</option>
                            <option>Thu</option>
                            <option>Fri</option>
                            <option>Sat</option>
                        </select>
                    </div>

                    <div>
                        <label>OPD Timings</label>

                        <div className="opd-checkbox">
                            <input
                                type="checkbox"
                                checked={form.timeSlots.includes("10:00-12:00")}
                                onChange={() => toggleSlot("10:00-12:00")}
                            />
                            <span>Morning (10:00 – 12:00)</span>
                        </div>

                        <div className="opd-checkbox">
                            <input
                                type="checkbox"
                                checked={form.timeSlots.includes("05:00-07:00")}
                                onChange={() => toggleSlot("05:00-07:00")}
                            />
                            <span>Evening (05:00 – 07:00)</span>
                        </div>
                    </div>


                    <div>
                        <label>Consultation Fee (₹)</label>
                        <input
                            type="number"
                            name="consultationFee"
                            required
                            value={form.consultationFee}
                            onChange={handleChange}
                        />
                    </div>

                    <div>
                        <label>Doctor Image</label>
                        <input
                            type="file"
                            accept="image/*"
                            name="image"
                            onChange={handleChange}
                        />
                        <small className="text-muted">
                            Image must exist in <b>public/Doctorimages</b>
                        </small>
                    </div>

                </div>

                <div className="form-actions">
                    <button type="submit">
                        <i className="bi bi-person-plus-fill"></i>
                        {editDoctor ? " Update Doctor" : " Add Doctor"}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default DoctorForm;
