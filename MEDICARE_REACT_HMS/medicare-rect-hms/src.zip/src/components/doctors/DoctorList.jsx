import { useEffect, useState } from "react";
import { getDoctors, deleteDoctor } from "../../services/doctorService";
import "../../assets/css/components/doctor-list.css";

const DoctorList = ({ onEdit }) => {
    const [grouped, setGrouped] = useState({});

    const loadDoctors = () => {
        getDoctors().then((res) => {
            const byDept = res.data.reduce((acc, d) => {
                acc[d.department] = acc[d.department] || [];
                acc[d.department].push(d);
                return acc;
            }, {});
            setGrouped(byDept);
        });
    };

    useEffect(() => {
        loadDoctors();
    }, []);

    const handleDelete = async (id) => {
        if (window.confirm("Delete this doctor?")) {
            await deleteDoctor(id);
            loadDoctors();
        }
    };

    return (
        <>
            {Object.keys(grouped).map((dept) => (
                <div key={dept} className="doctor-table-card">
                    <div className="doctor-table-header">
                        <h6>{dept}</h6>
                        <span>Total: {grouped[dept].length}</span>
                    </div>

                    <table className="doctor-table">
                        <thead>
                            <tr>
                                <th>Doctor</th>
                                <th>Days</th>
                                <th>OPD Time</th>
                                <th>Fee</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {grouped[dept].map((doc) => (
                                <tr key={doc.id}>
                                    <td>
                                        <div className="doctor-info">
                                            <img
                                                src={`/Doctorimages/${doc.image}`}
                                                alt={doc.name}
                                                className="doctor-avatar"
                                            />
                                            {doc.name}
                                        </div>
                                    </td>
                                    <td>{doc.availableDays.join(", ")}</td>
                                    <td>{doc.timeSlots.join(", ")}</td>
                                    <td>₹{doc.consultationFee}</td>
                                    <td>
                                        <div className="doctor-actions">
                                            <button className="icon-btn edit" onClick={() => onEdit(doc)}>
                                                <i className="bi bi-pencil"></i>
                                            </button>
                                            <button className="icon-btn delete" onClick={() => handleDelete(doc.id)}>
                                                <i className="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            ))}
        </>
    );
};

export default DoctorList;
