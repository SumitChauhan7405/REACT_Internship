const Admissions = () => {
  return <h4>Admissions</h4>;
};

export default Admissions;
