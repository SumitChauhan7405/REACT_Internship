const Appointments = () => {
  return <h4>Appointments</h4>;
};

export default Appointments;
