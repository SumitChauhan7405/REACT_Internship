const Billing = () => {
  return <h4>Billing</h4>;
};

export default Billing;
