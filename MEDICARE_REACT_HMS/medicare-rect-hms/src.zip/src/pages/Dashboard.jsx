const Dashboard = () => {
  return <h4>Dashboard</h4>;
};

export default Dashboard;
