import { useEffect, useState } from "react";
import axios from "axios";
import "../assets/css/pages/dashboard.css";

const Dashboard = () => {
  const [counts, setCounts] = useState({
    patients: 0,
    doctors: 0,
    rooms: 0,
    admissions: 0,

    admittedPatients: 0,
    pendingLabs: 0,
    surgeriesToday: 0,
    pendingDischarges: 0,
    unpaidBills: 0
  });

  /* ======================
     LOAD DASHBOARD DATA
  ======================= */
  const loadCounts = async () => {
    try {
      const [
        patientsRes,
        doctorsRes,
        roomsRes,
        admissionsRes,
        labsRes,
        surgeriesRes,
        billsRes
      ] = await Promise.all([
        axios.get("http://localhost:5000/patients"),
        axios.get("http://localhost:5000/doctors"),
        axios.get("http://localhost:5000/rooms"),
        axios.get("http://localhost:5000/admissions"),
        axios.get("http://localhost:5000/labTests"),
        axios.get("http://localhost:5000/surgeries"),
        axios.get("http://localhost:5000/bills")
      ]);

      const today = new Date().toISOString().split("T")[0];

      setCounts({
        patients: patientsRes.data.length,
        doctors: doctorsRes.data.length,
        rooms: roomsRes.data.length,
        admissions: admissionsRes.data.length,

        admittedPatients: admissionsRes.data.filter(
          a => a.status === "ADMITTED"
        ).length,

        pendingLabs: labsRes.data.filter(
          l => l.status !== "COMPLETED"
        ).length,

        surgeriesToday: surgeriesRes.data.filter(
          s => s.scheduledDate === today
        ).length,

        pendingDischarges: admissionsRes.data.filter(
          a => a.status === "ADMITTED"
        ).length,

        unpaidBills: billsRes.data.filter(
          b => b.status === "UNPAID"
        ).length
      });
    } catch (error) {
      console.error("Dashboard load error", error);
    }
  };

  useEffect(() => {
    loadCounts();
  }, []);

  return (
    <div className="dashboard-page">
      <h3 className="page-title">Dashboard</h3>

      <div className="dashboard-cards">
        {/* PATIENTS */}
        <div className="dashboard-card">
          <div className="card-info">
            <span className="card-title">Patients</span>
            <h2>{counts.patients}</h2>
            <span className="card-badge">Live</span>
          </div>
          <div className="card-icon">
            <i className="bi bi-people"></i>
          </div>
        </div>

        {/* DOCTORS */}
        <div className="dashboard-card">
          <div className="card-info">
            <span className="card-title">Doctors</span>
            <h2>{counts.doctors}</h2>
            <span className="card-badge">Live</span>
          </div>
          <div className="card-icon">
            <i className="bi bi-person-badge"></i>
          </div>
        </div>

        {/* ROOMS */}
        <div className="dashboard-card">
          <div className="card-info">
            <span className="card-title">Rooms</span>
            <h2>{counts.rooms}</h2>
            <span className="card-badge">Live</span>
          </div>
          <div className="card-icon">
            <i className="bi bi-door-open"></i>
          </div>
        </div>

        {/* ADMISSIONS */}
        <div className="dashboard-card">
          <div className="card-info">
            <span className="card-title">Admissions</span>
            <h2>{counts.admissions}</h2>
            <span className="card-badge">Live</span>
          </div>
          <div className="card-icon">
            <i className="bi bi-hospital"></i>
          </div>
        </div>

        {/* CURRENTLY ADMITTED */}
        <div className="dashboard-card">
          <div className="card-info">
            <span className="card-title">Currently Admitted</span>
            <h2>{counts.admittedPatients}</h2>
            <span className="card-badge">Active</span>
          </div>
          <div className="card-icon">
            <i className="bi bi-person-check"></i>
          </div>
        </div>

        {/* PENDING LAB TESTS */}
        <div className="dashboard-card">
          <div className="card-info">
            <span className="card-title">Pending Lab Tests</span>
            <h2>{counts.pendingLabs}</h2>
            <span className="card-badge">Action</span>
          </div>
          <div className="card-icon">
            <i className="bi bi-beaker"></i>
          </div>
        </div>

        {/* SURGERIES TODAY */}
        <div className="dashboard-card">
          <div className="card-info">
            <span className="card-title">Surgeries Today</span>
            <h2>{counts.surgeriesToday}</h2>
            <span className="card-badge">Today</span>
          </div>
          <div className="card-icon">
            <i className="bi bi-scissors"></i>
          </div>
        </div>

        {/* PENDING DISCHARGES */}
        <div className="dashboard-card">
          <div className="card-info">
            <span className="card-title">Pending Discharges</span>
            <h2>{counts.pendingDischarges}</h2>
            <span className="card-badge">Queue</span>
          </div>
          <div className="card-icon">
            <i className="bi bi-box-arrow-right"></i>
          </div>
        </div>

        {/* UNPAID BILLS */}
        <div className="dashboard-card">
          <div className="card-info">
            <span className="card-title">Unpaid Bills</span>
            <h2>{counts.unpaidBills}</h2>
            <span className="card-badge">Billing</span>
          </div>
          <div className="card-icon">
            <i className="bi bi-cash-coin"></i>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
