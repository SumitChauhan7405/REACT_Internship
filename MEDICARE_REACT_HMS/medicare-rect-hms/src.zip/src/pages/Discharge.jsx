const Discharge = () => {
  return <h4>Discharge</h4>;
};

export default Discharge;
