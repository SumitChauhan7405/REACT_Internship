import { useState } from "react";
import DoctorForm from "../components/doctors/DoctorForm";
import DoctorList from "../components/doctors/DoctorList";

const Doctors = () => {
  const [refresh, setRefresh] = useState(false);
  const [editDoctor, setEditDoctor] = useState(null);

  return (
    <>
      <DoctorForm
        onSuccess={() => setRefresh(!refresh)}
        editDoctor={editDoctor}
        clearEdit={() => setEditDoctor(null)}
      />

      <DoctorList
        key={refresh}
        onEdit={(doc) => setEditDoctor(doc)}
      />
    </>
  );
};

export default Doctors;
