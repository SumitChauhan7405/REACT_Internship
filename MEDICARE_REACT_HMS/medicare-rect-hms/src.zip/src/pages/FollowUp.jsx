const FollowUp = () => {
  return <h4>FollowUp</h4>;
};

export default FollowUp;
