const Lab = () => {
  return <h4>Lab</h4>;
};

export default Lab;
