const Surgery = () => {
  return <h4>Surgery</h4>;
};

export default Surgery;
