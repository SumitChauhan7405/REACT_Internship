const DoctorPatients = () => {
  return (
    <div>
      <h3>My Patients</h3>
      <p>Only patients assigned to you will appear here.</p>
    </div>
  );
};

export default DoctorPatients;
