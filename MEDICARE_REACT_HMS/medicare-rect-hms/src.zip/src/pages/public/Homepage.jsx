const Homepage = () => {
  return <h4>This is public side Homepage</h4>;
};

export default Homepage;
